//import { Component } from '@angular/core';
//import { products } from './products';
//import { sampleCustomers } from './customers';
import { Component, OnInit } from '@angular/core'; 
import { GetCustomersService } from './get-customers.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  constructor(private getCustomersService: GetCustomersService) { }
  public gridData: any[] = null;
  ngOnInit() {
  this.getCustomers();
  }
  public getCustomers(){
  this.getCustomersService.getCustomers().subscribe((data: any) => {
  this.gridData = data.response.getCustomer.getCustomer;
  console.log(data);
  });
  }
  }
  