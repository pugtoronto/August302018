import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GetCustomersService {

  API_URL = 'http://localhost:8810/hello/rest/helloService/customer';
  constructor(private httpClient: HttpClient) {}
  getCustomers(){ return this.httpClient.get(`${this.API_URL}`); }
  
}
